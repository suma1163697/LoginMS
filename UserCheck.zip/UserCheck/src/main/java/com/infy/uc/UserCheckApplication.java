package com.infy.uc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserCheckApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserCheckApplication.class, args);
	}

}
