package com.infy.uc.dto;



import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.xml.bind.annotation.XmlRootElement;

import org.hibernate.validator.constraints.Length;

import com.infy.uc.entity.UserEntity;

@XmlRootElement
public class UserDTO {
	@NotNull(message="{user.name.must}")
	String id;
	@Length(min = 8,message = "{user.password.length}")
	@NotNull(message="{user.password.must}")
	@Pattern(regexp = "([A-Z]{1,}[a-z]{1,}[0-9]{1,}[!@#&()–[{}]:;',?/*~$^+=<>]{1,})",message="{user.password.invalid}")
	String pw;
	@NotNull(message="{user.status.must}")
	@Pattern(regexp = "(active|inactive)",message="{user.status.invalid}")
	String status;
	@Override
	public String toString() {
		return "UserDTO [id=" + id + ", pw=" + pw + ", status=" + status + "]";
	}
	public UserDTO(String id, String pw, String status) {
		super();
		this.id = id;
		this.pw = pw;
		this.status = status;
	}
	public UserDTO() {
		// TODO Auto-generated constructor stub
		super();
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public static UserDTO prepareDTO(UserEntity ue)
	{
		UserDTO ud=new UserDTO();
		ud.setId(ue.getId());
		ud.setPw(ue.getPw());
		ud.setStatus(ue.getStatus());
		return ud;
	}

}
