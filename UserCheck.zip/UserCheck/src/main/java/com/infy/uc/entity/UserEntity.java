package com.infy.uc.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.infy.uc.dto.UserDTO;
@Entity
@Table(name = "User")
public class UserEntity {
	@Id
	String id;
	String pw;
	String status;
	@Override
	public String toString() {
		return "UserEntity [id=" + id + ", pw=" + pw + ", status=" + status + "]";
	}
	public UserEntity(String id, String pw, String status) {
		super();
		this.id = id;
		this.pw = pw;
		this.status = status;
	}
	public UserEntity() {
		// TODO Auto-generated constructor stub
		super();
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public static UserEntity prepareEntity(UserDTO udto)
	{
		UserEntity ue=new UserEntity();
		ue.setId(udto.getId());
		ue.setPw(udto.getPw());
		ue.setStatus(udto.getStatus());
		return ue;
		
	}
	

}
